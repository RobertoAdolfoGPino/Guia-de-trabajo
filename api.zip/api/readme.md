# Router de Express

* Middleware completo
* Sistema de Routeo
* "Mini app"
* Manejadores de ruta montables y modulares