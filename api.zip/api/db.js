const mongoose= require('mongoose');
const connectionString= 'mongodb+srv://themostergamer:t6VircED3PZXeGc7@cluster0.llclqa1.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(connectionString,(err)=> {
    if(err){
        console.log('There was an error: ${err}');
    }else{
        console.log('Database connected');
    }
});